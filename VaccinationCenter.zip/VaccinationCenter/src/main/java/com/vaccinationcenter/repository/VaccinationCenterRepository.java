package com.vaccinationcenter.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;


import com.vaccinationcenter.entities.VaccinationCenter;

public interface VaccinationCenterRepository extends CrudRepository<VaccinationCenter, Integer> {

	List<VaccinationCenter> findByCenterName(String centerName);
	
	List<VaccinationCenter> findAll();
}