package com.vaccinationcenter.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vaccinationcenter.entities.Citizen;

public interface CitizenRepository extends JpaRepository<Citizen, Integer> {

	List<Citizen> findByCenterCenterName(String centerName);

}